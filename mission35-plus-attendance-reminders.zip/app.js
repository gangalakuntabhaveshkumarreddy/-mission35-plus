const KEY='mission35plus.v2';
const defaults={subjects:[],attendance:[],reminders:[],checks:{},settings:{},};
let data=load();
const tasks=[
 ['water','Drink water regularly'],['movement','Workout / movement'],['study','College study or homework'],['selfcare','Skincare / personal care'],['kindness','One kind or helpful action'],['project','Mission 35 / AI project'],['winddown','Prepare for tomorrow']
];
const $=id=>document.getElementById(id);
const today=()=>new Date().toLocaleDateString('en-CA');
const niceDate=d=>{if(!d)return 'No date';const x=new Date(d+'T12:00:00');return x.toLocaleDateString(undefined,{day:'numeric',month:'short',year:'numeric'});};
function load(){try{return {...structuredClone(defaults),...JSON.parse(localStorage.getItem(KEY)||'{}')};}catch{return structuredClone(defaults)}}
function save(){localStorage.setItem(KEY,JSON.stringify(data));}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function toast(s){const t=$('toast');t.textContent=s;t.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove('show'),2400);}
function go(tab){document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active',p.id===tab));document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));window.scrollTo({top:0,behavior:'smooth'});if(tab==='attendance')renderAttendance();if(tab==='reminders')renderReminders();}
document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.tab)));
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));
function renderHome(){
 $('todayLabel').textContent=new Date().toLocaleDateString(undefined,{weekday:'short',day:'numeric',month:'short'});
 $('greeting').textContent=new Date().getHours()<12?'Start strong.':new Date().getHours()<18?'Keep your momentum.':'Finish the day well.';
 data.checks[today()] ||= {};
 const done=tasks.filter(t=>data.checks[today()][t[0]]).length;
 $('doneCount').textContent=`${done}/${tasks.length}`;
 $('checklist').innerHTML=tasks.map(([id,label])=>`<label class="task ${data.checks[today()][id]?'done':''}"><input type="checkbox" data-check="${id}" ${data.checks[today()][id]?'checked':''}><span class="task-name">${label}</span></label>`).join('');
 document.querySelectorAll('[data-check]').forEach(c=>c.addEventListener('change',()=>{data.checks[today()][c.dataset.check]=c.checked;save();renderHome();}));
 const total=data.attendance.length,present=data.attendance.filter(a=>a.status==='present'||a.status==='od').length;
 $('overallPct').textContent=total?Math.round(present/total*100)+'%':'—';$('classesCount').textContent=total;$('subjectsCount').textContent=data.subjects.length;
 const next=data.reminders.filter(r=>!r.done).sort((a,b)=>(a.date+'T'+a.time).localeCompare(b.date+'T'+b.time)).slice(0,3);
 $('upcoming').innerHTML=next.length?next.map(reminderHtml).join(''):'<div class="empty">No reminders yet. Add one to keep your day on track.</div>';
}
$('resetToday').onclick=()=>{if(confirm("Reset today's checklist?")){data.checks[today()]={};save();renderHome();toast('Checklist reset.');}};
$('subjectForm').addEventListener('submit',e=>{e.preventDefault();const name=$('subjectName').value.trim();if(!name)return;if(data.subjects.some(s=>s.name.toLowerCase()===name.toLowerCase()))return toast('Subject already exists.');data.subjects.push({id:crypto.randomUUID(),name});save();$('subjectName').value='';renderAttendance();renderHome();toast('Subject added.');});
function renderAttendance(){
 const sel=$('attendanceSubject');sel.innerHTML='<option value="">Choose subject</option>'+data.subjects.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join('');
 if(!data.subjects.length)$('subjectSummary').innerHTML='<div class="empty">Add a subject above to start logging attendance.</div>';
 else $('subjectSummary').innerHTML=data.subjects.map(s=>{const rows=data.attendance.filter(a=>a.subjectId===s.id);const attended=rows.filter(a=>a.status==='present'||a.status==='od').length;const pct=rows.length?Math.round(attended/rows.length*100):0;return `<div class="summary-card"><div class="summary-top"><div><strong>${esc(s.name)}</strong><div class="muted tiny">${attended} attended / ${rows.length} logged classes</div></div><strong>${rows.length?pct+'%':'—'}</strong></div><div class="bar"><span style="width:${pct}%"></span></div><div class="inline-actions"><button class="small-btn" data-delete-subject="${s.id}">Delete subject</button></div></div>`}).join('');
 const rows=[...data.attendance].sort((a,b)=>(b.date+a.createdAt).localeCompare(a.date+b.createdAt)).slice(0,50);
 $('attendanceRecords').innerHTML=rows.length?rows.map(a=>{const s=data.subjects.find(s=>s.id===a.subjectId);return `<div class="record"><div class="record-top"><div><strong>${esc(s?.name||'Deleted subject')}</strong><div class="muted tiny">${niceDate(a.date)}${a.note?' · '+esc(a.note):''}</div></div><span class="pill ${a.status==='present'?'present':a.status==='absent'?'absent':''}">${a.status==='od'?'On duty':a.status[0].toUpperCase()+a.status.slice(1)}</span></div><div class="inline-actions"><button class="small-btn" data-edit-att="${a.id}">Edit</button><button class="small-btn" data-delete-att="${a.id}">Delete</button></div></div>`}).join(''):'<div class="empty">Your attendance records will appear here.</div>';
 document.querySelectorAll('[data-delete-subject]').forEach(b=>b.onclick=()=>{const s=data.subjects.find(x=>x.id===b.dataset.deleteSubject);if(confirm(`Delete ${s.name} and its attendance records?`)){data.subjects=data.subjects.filter(x=>x.id!==s.id);data.attendance=data.attendance.filter(a=>a.subjectId!==s.id);save();renderAttendance();renderHome();}});
 document.querySelectorAll('[data-delete-att]').forEach(b=>b.onclick=()=>{data.attendance=data.attendance.filter(a=>a.id!==b.dataset.deleteAtt);save();renderAttendance();renderHome();toast('Record deleted.');});
 document.querySelectorAll('[data-edit-att]').forEach(b=>b.onclick=()=>{const a=data.attendance.find(x=>x.id===b.dataset.editAtt);$('attendanceSubject').value=a.subjectId;$('attendanceDate').value=a.date;$('attendanceStatus').value=a.status;$('attendanceNote').value=a.note||'';data.editingAttendance=a.id;$('attendanceForm').querySelector('button[type=submit]').textContent='Update attendance';window.scrollTo({top:0,behavior:'smooth'});});
}
$('attendanceDate').value=today();
$('attendanceForm').addEventListener('submit',e=>{e.preventDefault();const subjectId=$('attendanceSubject').value,date=$('attendanceDate').value,status=$('attendanceStatus').value,note=$('attendanceNote').value.trim();if(!subjectId)return toast('Add and select a subject first.');const existing=data.attendance.find(a=>a.subjectId===subjectId&&a.date===date);const id=data.editingAttendance||existing?.id||crypto.randomUUID();const record={id,subjectId,date,status,note,createdAt:new Date().toISOString()};data.attendance=data.attendance.filter(a=>a.id!==id&&!(a.subjectId===subjectId&&a.date===date));data.attendance.push(record);delete data.editingAttendance;save();$('attendanceNote').value='';$('attendanceForm').querySelector('button[type=submit]').textContent='Save attendance';renderAttendance();renderHome();toast('Attendance saved.');});
$('clearAttendance').onclick=()=>{if(confirm('Delete all attendance records? Subjects will remain.')){data.attendance=[];save();renderAttendance();renderHome();toast('Attendance records cleared.');}};
$('exportAttendance').onclick=()=>{const rows=[['Subject','Date','Status','Note'],...data.attendance.map(a=>[data.subjects.find(s=>s.id===a.subjectId)?.name||'',a.date,a.status,a.note||''])];download('mission35-attendance.csv',rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n'),'text/csv');};
$('reminderDate').value=today();$('reminderTime').value='19:00';
$('reminderForm').addEventListener('submit',e=>{e.preventDefault();data.reminders.push({id:crypto.randomUUID(),title:$('reminderTitle').value.trim(),date:$('reminderDate').value,time:$('reminderTime').value,repeat:$('reminderRepeat').value,category:$('reminderCategory').value,done:false,notifiedKey:''});save();$('reminderTitle').value='';renderReminders();renderHome();toast('Reminder added.');});
function reminderHtml(r){return `<div class="reminder"><div class="reminder-top"><div><strong>${esc(r.title)}</strong><div class="muted tiny">${niceDate(r.date)} · ${esc(r.time)} · ${esc(r.category)}${r.repeat!=='none'?' · '+esc(r.repeat):''}</div></div><span class="pill">${r.done?'Done':'Upcoming'}</span></div></div>`;}
function renderReminders(){const rows=[...data.reminders].sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));$('reminderList').innerHTML=rows.length?rows.map(r=>`<div class="reminder"><div class="reminder-top"><div><strong>${esc(r.title)}</strong><div class="muted tiny">${niceDate(r.date)} · ${esc(r.time)} · ${esc(r.category)}${r.repeat!=='none'?' · '+esc(r.repeat):''}</div></div><span class="pill">${r.done?'Done':'Planned'}</span></div><div class="inline-actions"><button class="small-btn" data-toggle-rem="${r.id}">${r.done?'Mark open':'Mark done'}</button><button class="small-btn" data-delete-rem="${r.id}">Delete</button></div></div>`).join(''):'<div class="empty">No reminders yet. Add your first reminder above.</div>';
document.querySelectorAll('[data-toggle-rem]').forEach(b=>b.onclick=()=>{const r=data.reminders.find(x=>x.id===b.dataset.toggleRem);r.done=!r.done;save();renderReminders();renderHome();});
document.querySelectorAll('[data-delete-rem]').forEach(b=>b.onclick=()=>{data.reminders=data.reminders.filter(x=>x.id!==b.dataset.deleteRem);save();renderReminders();renderHome();toast('Reminder deleted.');});}
$('enableNotifications').onclick=async()=>{if(!('Notification'in window))return toast('Notifications are not supported in this browser.');try{const p=await Notification.requestPermission();toast(p==='granted'?'Notifications enabled where browser permits.':'Permission not granted.');}catch{toast('Could not request notification permission.');}};
function checkDue(){if(!('Notification'in window)||Notification.permission!=='granted')return;const now=new Date();for(const r of data.reminders){if(r.done)continue;const due=new Date(r.date+'T'+r.time);const key=r.date+'T'+r.time;if(now>=due&&now-due<2*60*60*1000&&r.notifiedKey!==key){try{new Notification('Mission 35 Plus',{body:r.title});r.notifiedKey=key;save();}catch{}}}}
$('exportBackup').onclick=()=>download('mission35-plus-backup.json',JSON.stringify(data,null,2),'application/json');
$('importBackup').addEventListener('change',async e=>{const f=e.target.files[0];if(!f)return;try{const incoming=JSON.parse(await f.text());if(!incoming||!Array.isArray(incoming.subjects)||!Array.isArray(incoming.attendance)||!Array.isArray(incoming.reminders))throw Error();if(!confirm('Restore this backup and replace current app data? Download a backup first if needed.'))return;data={...structuredClone(defaults),...incoming};save();renderAll();toast('Backup restored.');}catch{toast('That backup file is not valid.');}e.target.value='';});
$('wipeAll').onclick=()=>{if(confirm('Permanently delete all Mission 35 Plus data stored in this browser?')){data=structuredClone(defaults);save();renderAll();toast('App data deleted.');}};
function download(name,content,type){const a=document.createElement('a'),url=URL.createObjectURL(new Blob([content],{type}));a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function renderAll(){renderHome();renderAttendance();renderReminders();}
renderAll();checkDue();setInterval(checkDue,30000);
if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
